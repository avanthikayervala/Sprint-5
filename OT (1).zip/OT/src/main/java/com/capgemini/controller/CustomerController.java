package com.capgemini.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.entity.Customer;
import com.capgemini.exceptions.ResourceNotFoundException;
import com.capgemini.service.CustomerService;
import com.capgemini.serviceimpl.CustomerServiceImpl;

@RestController
@RequestMapping("/api")
public class CustomerController {
	public static final Logger logger = LoggerFactory.getLogger(CustomerController.class);
	
	@Autowired
	private CustomerService customerService;

	@GetMapping("/customer")
	public List<Customer> getAllCustomers() {
		logger.info("Get all Customer Details");
		return (List<Customer>) CustomerService.getAllCustomers();
	}

	@GetMapping("/Customer/{id}")
	public ResponseEntity<Customer> getCustomerById(@PathVariable(value = "id") Integer customerid)
			throws ResourceNotFoundException {
		logger.info("Get customer details by id");
		Customer customer = CustomerService.findCustomerById(customerid);
		return ResponseEntity.ok(customer);
	}

	@PostMapping("/customer")
	public Customer saveCustomer(@RequestBody Customer Customer1) {
		logger.info("Add customer details");
		return customerService.saveCustomer(Customer1);
	}
   /* //http://localhost:9091/api/customer/1
	@PutMapping("/customer/{id}")
	public ResponseEntity<Customer> updateCustomerById(@PathVariable(value = "id") Integer customerid,
			@RequestBody Customer customer) throws ResourceNotFoundException {
		logger.info("Update customer details by id");
	Customer result = customerService.updateCustomer(customerid, customer);
	return ResponseEntity.ok(result);
} */
	
//
//	@DeleteMapping("/customer/{id}")
//	public Map<String, Boolean> deletePolicy(@PathVariable(value = "id") Integer customerId,
//			@RequestBody Customer customer) throws ResourceNotFoundException {
//		logger.info("Delete customer details by id");
//		Customer customer1 = customerService.findCustomerById(customerId);
//		customerService.deleteCustomer(customer1);
//		Map<String, Boolean> response = new HashMap<>();
//		response.put("deleted", Boolean.TRUE);
//		return response;
//
//	}
}