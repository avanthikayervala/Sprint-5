package com.capgemini.controller;

 

import java.util.List;

 


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

 

import com.capgemini.entity.HealthModule;
import com.capgemini.exceptions.ResourceNotFoundException;
import com.capgemini.service.CustomerDetailsService;

@RestController
@RequestMapping("/api")

 

public class HealthModuleController {
          @Autowired
          private CustomerDetailsService customerService;
          @GetMapping("/customerdetails")
          public List<HealthModule> getAllUserDetails() { 
                     return customerService.getAllCustomerDetails();
                     }
          @PostMapping("/customerdetails")

 

          public HealthModule createCustomer( @RequestBody HealthModule health) {

 

                     return customerService.saveCustomerDetails(health);

 

          } 
          @GetMapping("/customerdetails/{id}")
          public ResponseEntity<HealthModule> getCustomerById(@PathVariable(value = "id") Integer medicalId) throws ResourceNotFoundException {

                     HealthModule health = customerService.getCustomerDetailsById(medicalId);

                     return  ResponseEntity.ok(health);
          }
          @PutMapping("/customerdetails/{id}")

 

          public ResponseEntity<HealthModule> updateCustomerDetails(@PathVariable(value = "id") Integer medicalId,

 

                                @RequestBody HealthModule healths) throws ResourceNotFoundException {

 

                     HealthModule health = customerService.upadateCustomerDetailsById(medicalId, healths);

 

                     return  ResponseEntity.ok(health);
          }

 

          @DeleteMapping("/userdetails/{id}")  

 

          public ResponseEntity<Boolean> deleteCustomerDetails(@PathVariable(value = "id") Integer medicalId,@RequestBody HealthModule health) throws ResourceNotFoundException     {

 

				Boolean health1 = customerService.deleteCustomerDetails(medicalId);

                     return  ResponseEntity.ok(health1);

 

          }

 

         

 

 

}