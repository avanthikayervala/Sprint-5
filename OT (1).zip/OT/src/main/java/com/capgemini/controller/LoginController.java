//package com.capgemini.controller;
//
// 
//
//import java.util.List;
//
// 
//
//import javax.xml.bind.ValidationException;
//
// 
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.DeleteMapping;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.PutMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
// 
//
//import com.capgemini.entity.Login;
//import com.capgemini.exceptions.ResourceNotFoundException;
//import com.capgemini.serviceimpl.LoginServiceImpl;
//
// 
//
//@RestController
//@RequestMapping("/api")
//public class LoginController {
//    public static final Logger logger = LoggerFactory.getLogger(LoginController.class);
//    @Autowired
//    private LoginServiceImpl loginServiceImpl;
//    @PostMapping("/addcustomercd")
//    public ResponseEntity<Login> addCredentials(@RequestBody Login l) throws ValidationException, ResourceNotFoundException {
//        Login addcustomer = loginServiceImpl.addCustomerCredentials(l);
//        logger.info("Adding the customer....");
//        return new ResponseEntity<Login> (addcustomer, HttpStatus.OK);
//          }
//    @PutMapping("/updateLogin/{customername}/{password}")
//    public ResponseEntity<String> updatecustomercd(@RequestBody Login l) throws ResourceNotFoundException {
//        String s = loginServiceImpl.updateCustomerCredentials(l.getCustomerName(), l.getPassword());
//        return new ResponseEntity<String>(s, HttpStatus.OK);
//          }
//    @DeleteMapping("/deletecustomercd")
//    public ResponseEntity<String> deleteCustomerCd(@RequestBody Login l) throws ValidationException, ResourceNotFoundException {
//        String s = loginServiceImpl.deleteCustomerCredentials(l.getCustomerName(), l.getPassword());
//        logger.info("Deleting the customer.....");
//        return new ResponseEntity<String>(s, HttpStatus.OK);
//          }
//    @GetMapping("/getAll")
//    public List<Login> getAll() {
//        logger.info("Get all Login");
//        return loginServiceImpl.getAllCustomerCredentials();
//          }
//    @GetMapping("/login/{customer}/{password}")
//    public ResponseEntity<Login> getLoginByCustomerName(@PathVariable(value = "customer") String customername,@PathVariable(value = "password") String password) throws ResourceNotFoundException {
//        logger.info("Login by customer and password");
//        Login login=loginServiceImpl.getLoginByCustomerName(customername, password);
//        return ResponseEntity.ok(login);
//          }        
//
//}