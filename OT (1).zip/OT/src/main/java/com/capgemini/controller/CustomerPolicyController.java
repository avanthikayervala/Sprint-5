package com.capgemini.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.entity.CustomerPolicy;
import com.capgemini.exceptions.ResourceNotFoundException;


@RestController
@RequestMapping("/api")
public class CustomerPolicyController {
	
	public static final Logger logger = LoggerFactory.getLogger(CustomerPolicyController.class);
	
//	@Autowired
//	private CustomerPolicyServices customerPolicyService;
//
//	@GetMapping("/customerpolicy")
//	public List<CustomerPolicy> getAllCustomerPolicies() {
//		logger.info("Get all Customer Policy");
//		return customerPolicyService.getAllCustomerPolices();
//	}
//
//	@GetMapping("/customerpolicy/{customerid}")
//	ResponseEntity<CustomerPolicy> getByCustomerIdAndPolicyId(@PathVariable(value = "customerId") int customerId)
//			throws ResourceNotFoundException {
//		logger.info("Get Customer Policy by customer id");
//		CustomerPolicy customer = customerPolicyService.findByCustomerId(customerId);
//		return ResponseEntity.ok(customer);
//	}
//
//	@PostMapping("/customerpolicy")
//	public CustomerPolicy createCustomerPolicy(@RequestBody CustomerPolicy customerPolicy) {
//		logger.info("Add Customer Policy");
//		return customerPolicyService.saveCustomerPolicyById(customerPolicy);
//	}
//
//	@PutMapping("/customerPolicy/{customerid}/{policyNo}")
//	ResponseEntity<CustomerPolicy> updateCustomerPolicyById(@PathVariable(value = "userid") int customerid,
//			@PathVariable("policyNo") int policyNo, @RequestBody CustomerPolicy customerPolicy)
//			throws ResourceNotFoundException {
//		logger.info("Update Coustemer Policy by customer id and Policy No");
//		CustomerPolicy customerPolicyTemp = customerPolicyService.findByCustomerId(customerid);
//		CustomerPolicy Customer1 = customerPolicyService.updateCustomerPolicy(customerPolicyTemp.getCustomerPolicyId(),
//				customerPolicyTemp.getCustomerPolicyId(), customerPolicy);
//		return ResponseEntity.ok(Customer1);
//	}
//
//	@DeleteMapping("/customerpolicy/{id}")
//	public Map<String, Boolean> deleteCustomerPolicy(@PathVariable(value = "id") Integer customerpolicyid)
//			throws ResourceNotFoundException {
//		logger.info("Delete Customer Policy by customer id and Policy No");
//		CustomerPolicy customer = customerPolicyService.findCustomerPolicyById(customerpolicyid);
//		customerPolicyService.deleteCustomerPolicyById(customer);
//		Map<String, Boolean> response = new HashMap<>();
//		response.put("deleted", Boolean.TRUE);
//		return response;
//	}

}