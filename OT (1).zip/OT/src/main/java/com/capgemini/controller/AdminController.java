package com.capgemini.controller;

 

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

 

import com.capgemini.entity.Policy;

import com.capgemini.serviceimpl.PaymentServiceImpl;

 

@RestController
@RequestMapping("/api/admin")
public class AdminController {
    public static final Logger logger = LoggerFactory.getLogger(AdminController.class);
    @Autowired
    PaymentServiceImpl policyService;
    @GetMapping("/add-Policy")
    //http://localhost:9091/api/admin
    @PostMapping("/policy")
    public Policy saveCustomer(@RequestBody Policy policy1) {
        logger.info("Create Policy");
        return policyService.savePolicy(policy1);
  
    }
    //http://localhost:9091/api/admin
    @PutMapping("/update-policy")
    public Policy updateCustomer(@RequestBody Policy policy1) {
        logger.info("Update Policy");
        return policyService.savePolicy(policy1);
  
    }
    //http://localhost:9091/api/admin
    @DeleteMapping("/delete-policy")
    public Policy DeleteCustomer(@RequestBody Policy policy1) {
        logger.info("Update Policy");
        return policyService.savePolicy(policy1);
  
    }
}