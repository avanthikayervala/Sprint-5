package com.capgemini.controller;

 


import java.util.List;

 

import org.slf4j.Logger;

import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.entity.Policy;
import com.capgemini.exceptions.ResourceNotFoundException;
import com.capgemini.service.PolicyService;

@RestController
@RequestMapping("/api")
public class PolicyController {
    public static final Logger logger = LoggerFactory.getLogger(PolicyController.class);
    @Autowired
    private PolicyService policyService;

    @GetMapping("/policy")
    public List<Policy> getAllPolicy() {

        logger.info("Get all Policy");

        return policyService.getAllPolicies();

    }

    @GetMapping("/policy/{id}")

    public ResponseEntity<Policy> getUserPolicyById(@PathVariable(value = "id") Integer policyid)
            throws ResourceNotFoundException {

        logger.info("Get policy by id");

        Policy policy = policyService.findPolicyById(policyid);
        return ResponseEntity.ok(policy);
    }

    @PostMapping("/add-policy")
     public ResponseEntity<Policy> savePolicy(@RequestBody Policy policy) throws ResourceNotFoundException {
        logger.info("Create Policy");
        Policy result= policyService.savePolicy(policy);
        return ResponseEntity.ok(result);
    }

    @PutMapping("/update-policy")
    public ResponseEntity<Policy> updatePolicyById(

            @RequestBody Policy policy) throws ResourceNotFoundException {

        logger.info("Update policy by id");

        Policy result = policyService.updatePolicy( policy);

        return ResponseEntity.ok(result);

    }

    @DeleteMapping("/policy/{id}")
    public ResponseEntity<Boolean> deleteUserPolicy(@PathVariable(value = "id") Integer policyid,
            @RequestBody Policy policy) throws ResourceNotFoundException {

        logger.info("Delete policy by id");

        Boolean policy1 = policyService.deletePolicy(policyid);

        return ResponseEntity.ok(policy1);

    }

}