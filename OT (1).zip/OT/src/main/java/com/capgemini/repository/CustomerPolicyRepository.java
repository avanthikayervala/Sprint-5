package com.capgemini.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.entity.CustomerPolicy;

@Repository
public interface CustomerPolicyRepository extends CrudRepository<CustomerPolicy,Integer>{

    @Query(value="select * from user_policy where user_id=?1 LIMIT 1",nativeQuery=true)
    CustomerPolicy findByUserId(int userId);
    @Query(value="select * from user_policy where user_policy_id=?1",nativeQuery=true)
      
	CustomerPolicy findByCustomerId(int customerId);

}
