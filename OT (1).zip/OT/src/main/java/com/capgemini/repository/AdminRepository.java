
package com.capgemini.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.entity.Admin;

@Repository
public interface AdminRepository extends CrudRepository<Admin, Integer> {

//	@Query("Select U from User U where U.customerId=?1 oder by U.customerId")
//	List<Customer> findByCustomerId(int id);

	//List<Customer> getCustomerById(String adminId);

	//List<Policy> getPolicies();

}
