package com.capgemini.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.entity.HealthModule;
import com.capgemini.service.CustomerDetailsService;

@Repository
public interface CustomerDetailsRepository{

	@Query(value="select * from healthmodule where Medical_Id=?1",nativeQuery=true)
    HealthModule findByMedicalId(Integer medicalId);

	HealthModule findById(Integer medicalId);

	void delete(HealthModule health);

	HealthModule save(HealthModule health);

	List<HealthModule> findAll();

}
