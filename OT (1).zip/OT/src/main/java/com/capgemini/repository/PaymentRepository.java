package com.capgemini.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.entity.CustomerPolicy;
import com.capgemini.entity.Payments;

@Repository
public interface PaymentRepository extends CrudRepository<Payments,Integer>{
	
	CustomerPolicy policy=new CustomerPolicy();
    
    @Query(value="select * from payment where user_id=?1 and policy_id=?2",nativeQuery=true)
    List<Payments> findByUserIdAndPolicyNo(int userId,int policyNo);

    @Query(value="select * from payment where recript_no=?1",nativeQuery=true)
    Payments findByReceiptNo(int receiptNo);

    @Query(value="select sum(amount) from payment where user_id=?1 and policy_id=?2",nativeQuery=true)
    Double findTotalAmountPaid(int userId,int policyNo);

	List<Payments> findAll();

	List<Payments> findByCustomerIdAndPolicyNo(int customerId, int policyNo);

}
