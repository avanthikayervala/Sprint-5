package com.capgemini.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.entity.Policy;


@Repository
public interface PolicyRepo extends CrudRepository<Policy,Integer>{

    

}
