package com.capgemini.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.capgemini.entity.Customer;
import com.capgemini.entity.Login;

public interface CustomerRepo extends JpaRepository<Customer,Integer>{
	
//    @Query(value="select * from user_details where user_id=?1",nativeQuery=true)
//    Login findByUserId(int userid);
    public Customer findByName(String j);
//	Login saveAll(Login customer1);
//	Login saveAll(Customer customer1);

	//public Customer update(Customer customer);

}
