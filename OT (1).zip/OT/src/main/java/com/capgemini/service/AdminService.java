package com.capgemini.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.capgemini.entity.Customer;
import com.capgemini.entity.CustomerPolicy;
import com.capgemini.entity.Payments;
import com.capgemini.entity.Policy;

@Service
public interface AdminService {
	
	    public List<Customer>getAllCustomers();
	    public Customer findCustomerById(Customer customer);
	    public boolean deleteCustomer(Customer customer);
	    public Customer saveCustomer(Customer customer);
	    public Customer updateCustomer(Integer CustomerId, Customer customer);
	    public List<Policy> getAllPolicies();
	    public List<CustomerPolicy> getCustomerPolicyById(Integer CustomerPolicyId);
	    public List<Payments> getAllPaymentsByCustomerId(Integer CustomerId);

}
