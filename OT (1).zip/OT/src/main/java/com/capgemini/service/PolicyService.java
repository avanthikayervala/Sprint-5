package com.capgemini.service;

 

import java.util.List;

 

import org.springframework.stereotype.Service;

 

import com.capgemini.entity.Policy;
import com.capgemini.exceptions.ResourceNotFoundException;

 

@Service
public interface PolicyService {

 

     public List<Policy> getAllPolicies();
     public Policy savePolicy(Policy policy) throws ResourceNotFoundException;
     public Policy updatePolicy( Policy policies) throws ResourceNotFoundException;
     public Policy findPolicyById(Integer policyid) throws ResourceNotFoundException;
     public Boolean deletePolicy(Integer policyid);

}