//package com.capgemini.service;
//
//import java.util.List;
//
//import org.springframework.stereotype.Service;
//
//import com.capgemini.entity.CustomerPolicy;
//import com.capgemini.exceptions.ResourceNotFoundException;
//
//@Service
//public interface CustomerPolicyServices {
//
//	public List<CustomerPolicy> getAllCustomerPolices();
//	public CustomerPolicy findCustomerPolicyById(Integer customerpolicyid) throws ResourceNotFoundException;
//	public boolean deleteCustomerPolicyById(CustomerPolicy customerpolicy) throws ResourceNotFoundException;
//	public CustomerPolicy saveCustomerPolicyById(CustomerPolicy user);
//	public CustomerPolicy updateCustomerPolicy(int customerId,int policyNo,CustomerPolicy user) throws ResourceNotFoundException;
//	public CustomerPolicy findByCustomerId(int customerId);
//}
