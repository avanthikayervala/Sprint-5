package com.capgemini.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.capgemini.entity.Payments;

@Service
public interface PaymentService {

	 List<Payments> getAll();
	    List<Payments> findAllCustomerId(int customerId);
	    public double findTotalAmountPaid(int customerId);
	    Payments findByReceiptNo(int receiptNo);
	    double findTotalAmountPaid(int userId, int policyNo);
	    List<Payments> findByUserIdAndPolicyNo(int userId, int policyNo);
		List<Payments> getall();
		Payments MakePayment(Payments pp);
		boolean deletePayment(Payments payment);
		List<Payments> getAll1();
		List<Payments> findByCustomerIdAndPolicyNo(int customerId, int policyNo);
		List<Payments> findByCustomerIdAndPolicyNo1(int customerId, int policyNo);
	    
}
