package com.capgemini.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.capgemini.entity.Customer;
import com.capgemini.entity.CustomerPolicy;
import com.capgemini.entity.Payments;
import com.capgemini.entity.Policy;

public interface CustomerService {

	public boolean updateCustomer(Customer customer);
	public static Iterable<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		return null;
	}
    public List<Policy> getAllPolicies();
    public List<CustomerPolicy>getAllCustomerPolicies();
    public List<Payments>getAllPayments(); 
    public static Customer findCustomerById(Integer customer) {
    	return null;
    }
	public  Customer saveCustomer(Customer customer1);
	
	public Customer updateCustomer(Integer customerid, Customer customer);
	
	}
   
