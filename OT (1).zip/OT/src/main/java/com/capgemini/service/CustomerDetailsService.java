package com.capgemini.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.capgemini.entity.HealthModule;
import com.capgemini.exceptions.ResourceNotFoundException;


public interface CustomerDetailsService {

	public List<HealthModule> getAllCustomerDetails();
	public HealthModule saveCustomerDetails(HealthModule health);
	public HealthModule upadateCustomerDetailsById(Integer medicalId,HealthModule healths) throws ResourceNotFoundException;
	//public boolean deleteCustomerDetails(Integer medicalId) throws ResourceNotFoundException;
    //public HealthModule getCustomerDetailsById(Integer medicalId) throws ResourceNotFoundException;
	public HealthModule getCustomerDetailsById(Integer medicalId) throws ResourceNotFoundException;
	public Boolean deleteCustomerDetails(Integer medicalId);

	
}
