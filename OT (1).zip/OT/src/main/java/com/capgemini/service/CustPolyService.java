package com.capgemini.service;

import java.util.List;

import com.capgemini.entity.CustomerPolicy;
import com.capgemini.exceptions.ResourceNotFoundException;


public interface CustPolyService {


	public boolean deleteCustomerPolicy(CustomerPolicy customerPolicy) throws ResourceNotFoundException;
	public CustomerPolicy findCustomerPolicyById1(Integer customerpolicyid)
			throws ResourceNotFoundException;
	public List<CustomerPolicy> getAllCustomerPolicies();
	public CustomerPolicy saveCustomerPolicy(CustomerPolicy customer);
	public List<CustomerPolicy> getAllCustomerPolices();
	public CustomerPolicy findCustomerPolicyById(Integer customerpolicyid) throws ResourceNotFoundException;
	public boolean deleteCustomerPolicyById(CustomerPolicy customerpolicy) throws ResourceNotFoundException;
	public CustomerPolicy saveCustomerPolicyById(CustomerPolicy user);
	public CustomerPolicy updateCustomerPolicy(int customerId,int policyNo,CustomerPolicy user) throws ResourceNotFoundException;
	public CustomerPolicy findByCustomerId(int customerId);
}
