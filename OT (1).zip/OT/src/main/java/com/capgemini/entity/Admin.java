package com.capgemini.entity;

import javax.persistence.Column;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="admin")
public class Admin {

 @Id
 @Column(name="adminId")
 private int adminId;
 
 @Column(name="adminName")
 private String adminName;
 @Column(name="adminContact")
 private Long adminContact;
 
public Admin() {
	super();
	// TODO Auto-generated constructor stub
}

public int getAdminId() {
	return adminId;
}
public void setAdminId(int adminId) {
	this.adminId = adminId;
}
public String getAdminName() {
	return adminName;
}
public void setAdminName(String adminName) {
	this.adminName = adminName;
}
public Long getAdminContact() {
	return adminContact;
}
public void setAdminContact(Long adminContact) {
	this.adminContact = adminContact;
}


}
