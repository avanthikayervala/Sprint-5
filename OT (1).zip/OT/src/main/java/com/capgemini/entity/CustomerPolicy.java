package com.capgemini.entity;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.ManyToAny;

@Entity(name="CUSTOMER_POLICY")
@Table(name="CUSTOMER_POLICY")
public class CustomerPolicy {
	@Id
    private int customerPolicyId;
    @ManyToOne
    @JoinColumn(name="CustomerId")
    private  Customer customer;
    @ManyToOne
    @JoinColumn(name="PolicyId")
    private Policy policy;
	private Date registeredDate;
	private int totalTime;
    private int monthOver;
    private double amountPaid;
	public CustomerPolicy() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getCustomerPolicyId() {
		return customerPolicyId;
	}
	public void setCustomerPolicyId(int customerPolicyId) {
		this.customerPolicyId = customerPolicyId;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	public Policy getPolicy() {
		return policy;
	}
	public void setPolicy(Policy policy) {
		this.policy = policy;
	}
	public Date getRegisteredDate() {
		return registeredDate;
	}
	public void setRegisteredDate(Date registeredDate) {
		this.registeredDate = registeredDate;
	}
	public int getTotalTime() {
		return totalTime;
	}
	public void setTotalTime(int totalTime) {
		this.totalTime = totalTime;
	}
	public int getMonthOver() {
		return monthOver;
	}
	public void setMonthOver(int monthOver) {
		this.monthOver = monthOver;
	}
	public double getAmountPaid() {
		return amountPaid;
	}
	public void setAmountPaid(double amountPaid) {
		this.amountPaid = amountPaid;
	}
	public static List<CustomerPolicy> findAll() {
		// TODO Auto-generated method stub
		return null;
	}
	public Integer getCustomerId() {
		// TODO Auto-generated method stub
		return null;
	}
	public void setCustomerId(Integer customerId) {
		// TODO Auto-generated method stub
		
	}
	public Object getPolicyId() {
		// TODO Auto-generated method stub
		return null;
	}
	public Object getAmount() {
		// TODO Auto-generated method stub
		return null;
	}
	public void setPolicyId(Object policyId) {
		// TODO Auto-generated method stub
		
	}
	public void setAmount(Object amount) {
		// TODO Auto-generated method stub
		
	}
	public CustomerPolicy findById(int customerPolicyId2) {
		// TODO Auto-generated method stub
		return null;
	}
	public static List<CustomerPolicy> findByCustomerIdAndPolicyId(int customerId, int policyNo) {
		// TODO Auto-generated method stub
		return null;
	}
	
	
    
	
}
