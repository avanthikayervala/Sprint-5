package com.capgemini.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity(name="CUSTOMER_DETAILS")
@Table(name="CUSTOMER_DETAILS")

public class Customer {
	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="id")
    private int id;
    
    @Column(name="name")
    private String name;
    

    @Column(name="mobile_no")
    private Long mobile_no;
    
    @Column(name="email")
    private String email;
    

    @Column(name="dob")
    private String dob;
    
    @Column(name="gender")
    private String gender;
    
    @Column(name="age")
    private int age;
    @Column(name="salary")
    private double salary;
    
    
	public Customer() {
		// TODO Auto-generated constructor stub
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public long getMobile_no() {
		return mobile_no;
	}
	public void setMobile_no(long mobile_no) {
		this.mobile_no = mobile_no;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public static Integer getCustomerId() {
		// TODO Auto-generated method stub
		return null;
	}
	public String getCustomerName() {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	

}
