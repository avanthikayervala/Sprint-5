package com.capgemini.serviceimpl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;

import com.capgemini.entity.Customer;
import com.capgemini.entity.CustomerPolicy;
import com.capgemini.entity.Payments;
import com.capgemini.entity.Policy;
import com.capgemini.exceptions.ResourceNotFoundException;
import com.capgemini.repository.CustomerRepo;
import com.capgemini.service.CustomerService;

@Service
@Transactional
public class CustomerServiceImpl implements CustomerService {

	public static final Logger logger = LoggerFactory.getLogger(CustomerServiceImpl.class);

	@Autowired
	private CustomerRepo customerRepository;

	// getting all customer data
	public Iterable<Customer> getAllCustomers() {
		logger.info("Customer Service get all");
		return customerRepository.findAll();

	}

	// finding customers by id
	public Customer findCustomerById(@PathVariable(value = "id") Integer customerid) throws ResourceNotFoundException {
		logger.info("Customer Service get by id");
		Customer customer = customerRepository.findById(customerid).get();
		if (customer == null) {
			new ResourceNotFoundException("Customer Policy not found for this id :: " + customerid);
		}
		return customer;
	}

	public boolean deleteCustomer(Customer customer) throws ResourceNotFoundException {
		logger.info("Customer Service Delete");
		Customer customer1 = customerRepository.findById(Customer.getCustomerId()).orElseThrow(
				() -> new ResourceNotFoundException("User Policy ot found for this id :: " + customer.getCustomerId()));

		customerRepository.delete(customer1);
		if (customer1 == null) {
			return true;
		}
		return false;

	}

//	public Login saveCustomer(Customer customer1) throws ValidationException {
//		logger.info("Customer Service Add customer");
//		String regex = "^[A-Z][a-z]{4,10}";
//		String j = customer1.getCustomerName();
//		String k = customer1.getCustomerName();
//		if (!j.matches(regex)) {
//			throw new ValidationException("invalid first name try again.."
//					+ "Rules --> first letter must be an alphabet and min 4 , max 10characters");
//		} else if (!k.matches(regex)) {
//			throw new ValidationException("invalid last name try again.."
//					+ "Rules --> first letter must be an alphabet and min 4 mx 10 characters");
//		} else {
//			return customerRepository.saveAll(customer1);
//		}
//
//	}

//	public Login updateCustomer(Integer customerid, Login customers) throws ResourceNotFoundException {
//		logger.info("Customer Service Update");
//		Login customer1 = new Login();
//		customer1.setCustomerName(customers.getCustomerName());
//		customer1.setCustomerName(customers.getCustomerName());
//		final Login updatedcustomer = customerRepository.saveAll(customer1);
//		return updatedcustomer;
//	}

	@Override
	public boolean updateCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<Policy> getAllPolicies() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<CustomerPolicy> getAllCustomerPolicies() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Payments> getAllPayments() {
		// TODO Auto-generated method stub
		return null;
	}

	public Customer updateCustomer(Integer customerid, Customer customer) {
		// TODO Auto-generated method stub
		return null;
	 }

	@Override
	public Customer saveCustomer(Customer customer1) {
		
		return customerRepository.save(customer1);
	}
	
	
	
	

}
