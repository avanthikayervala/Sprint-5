package com.capgemini.serviceimpl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.capgemini.entity.Customer;
import com.capgemini.entity.CustomerPolicy;
import com.capgemini.entity.Payments;
import com.capgemini.entity.Policy;
import com.capgemini.service.AdminService;

@Service
public class AdminServiceImpl implements AdminService {

	@Override
	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Customer findCustomerById(Customer customer) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean deleteCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Customer saveCustomer(Customer customer) {
		
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Customer updateCustomer(Integer CustomerId, Customer customer) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Policy> getAllPolicies() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<CustomerPolicy> getCustomerPolicyById(Integer CustomerPolicyId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Payments> getAllPaymentsByCustomerId(Integer CustomerId) {
		// TODO Auto-generated method stub
		return null;
	}

	
	

}
