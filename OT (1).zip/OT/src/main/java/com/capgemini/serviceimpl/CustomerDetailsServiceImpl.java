package com.capgemini.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.entity.HealthModule;
import com.capgemini.exceptions.ResourceNotFoundException;
import com.capgemini.repository.HealthRepository;
import com.capgemini.service.CustomerDetailsService;

@Service
@Transactional
public class CustomerDetailsServiceImpl implements CustomerDetailsService{

//	@Autowired
//	private CustomerDetailsRepository customerdetails;
	
	@Autowired
	private HealthRepository healthRepository;
	
	
	public HealthModule getCustomerDetailsById1(int medicalId) throws ResourceNotFoundException{
		HealthModule health=healthRepository.findById(medicalId).get();
		if(health==null) {
			new ResourceNotFoundException("Customer not found for this id :: " + medicalId);
			
		}
		return health;
	}
	
	public boolean deleteCustomerDetails1(Integer medicalId) throws ResourceNotFoundException {
		HealthModule health = healthRepository.findById(medicalId).get();
		if(health != null) {
			healthRepository.delete(health);
			return true;
		}else {
			throw new ResourceNotFoundException("Not Exist");
		}
	}
	
	public HealthModule updateCustomerDeatilsById(HealthModule health) throws ResourceNotFoundException {
		HealthModule result = healthRepository.findById(health.getMedicalId()).get();
		if(result != null) {
			return healthRepository.save(health);
		}else {
			throw new ResourceNotFoundException("Not foud");
		}
		
		
	}
	
	public HealthModule saveCustomerDetails1(HealthModule health) {
		return healthRepository.save(health);
		
	}
	public List<HealthModule> getAllCustomerDetails1(){
		return healthRepository.findAll();	}
	@Override
	public List<HealthModule> getAllCustomerDetails() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public HealthModule saveCustomerDetails(HealthModule health) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public HealthModule upadateCustomerDetailsById(Integer medicalId, HealthModule healths)
			throws ResourceNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public HealthModule getCustomerDetailsById(Integer medicalId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Boolean deleteCustomerDetails(Integer medicalId) {
		// TODO Auto-generated method stub
		return null;
	}
	
}