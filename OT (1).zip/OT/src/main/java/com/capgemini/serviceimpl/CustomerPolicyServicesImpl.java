//package com.capgemini.serviceimpl;
//
//import java.util.List;
//
//import javax.transaction.Transactional;
//
//import org.hibernate.annotations.common.util.impl.LoggerFactory;
//import org.slf4j.Logger;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//import org.springframework.web.bind.annotation.PathVariable;
//
//import com.capgemini.entity.CustomerPolicy;
//import com.capgemini.exceptions.ResourceNotFoundException;
//import com.capgemini.repository.CustomerPolicyRepository;
//import com.capgemini.service.CustomerPolicyServices;
//
//@Service
//@Transactional
//public class CustomerPolicyServicesImpl implements CustomerPolicyServices {
//
//	public static final Logger logger = (Logger) LoggerFactory.logger(CustomerPolicyServicesImpl.class);
//
//	@Autowired
//	private CustomerPolicyRepository customerpolicy;
//
//	public List<CustomerPolicy> getAllCustomerPolicies() {
//		logger.info("Customer Policy Service get all");
//		return CustomerPolicy.findAll();
//	}
//
//	public CustomerPolicy findCustomerPolicyById1(@PathVariable(value = "id") Integer customerpolicyid)
//			throws ResourceNotFoundException {
//		logger.info("Customer Policy Service get by Id");
//		CustomerPolicy customer = customerpolicy.findByCustomerId(customerpolicyid);
//		if (customer == null) {
//			new ResourceNotFoundException("User Policy not found for this id :: " + customerpolicyid);
//		}
//		return customer;
//	}
//
//	public boolean deleteCustomerPolicy(CustomerPolicy customerPolicy) throws ResourceNotFoundException {
//		logger.info("User Policy Service delete by Id");
//		CustomerPolicy customer = customerpolicy.findById(customerPolicy.getCustomerId())
//				.orElseThrow(() -> new ResourceNotFoundException(
//						"User Policy ot found for this id :: " + customerPolicy.getCustomerPolicyId()));
//
//		customerpolicy.delete(customer);
//		if (customer == null) {
//			return true;
//		}
//		return false;
//	}
//
//	public CustomerPolicy findByCustomerId(int customerId) {
//		logger.info("Customer Policy Service get by customer Id and Policy No");
//		return customerpolicy.findByUserId(customerId);
//	}
//
//	public CustomerPolicy saveCustomerPolicy(CustomerPolicy customer) {
//		logger.info("Customer Policy Service Add");
//
//		return customerpolicy.save(customer);
//	}
//
//	public CustomerPolicy updateCustomerPolicy(int customerId, int policyNo, CustomerPolicy customer)
//			throws ResourceNotFoundException {
//		logger.info("Customer Policy Service update");
//		CustomerPolicy customer1 = customerpolicy.findByCustomerId(customerId);
//		if (customer1 == null) {
//			new ResourceNotFoundException("User Policy not found for this id :: " + customerId);
//		}
//		customer1.setCustomerId(customer.getCustomerId());
//		customer1.setPolicyId(customer.getPolicyId());
//		customer1.setRegisteredDate(customer.getRegisteredDate());
//		customer1.setAmount(customer.getAmount());
//		customer1.setTotalTime(customer.getTotalTime());
//		customer1.setMonthOver(customer.getMonthOver());
//		customer1.setAmountPaid(customer.getAmountPaid());
//		final CustomerPolicy updatedcustomerPolicy = customerpolicy.save(customer1);
//		return updatedcustomerPolicy;
//	}
//
//	public List<CustomerPolicy> saveAll() {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	@Override
//	public List<CustomerPolicy> getAllCustomerPolices() {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	@Override
//	public CustomerPolicy findCustomerPolicyById(Integer customerpolicyid) throws ResourceNotFoundException {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	@Override
//	public boolean deleteCustomerPolicyById(CustomerPolicy customerpolicy) throws ResourceNotFoundException {
//		// TODO Auto-generated method stub
//		return false;
//	}
//
//	public List<CustomerPolicy> findAll() {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	public Object findById(int customerPolicyId) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	@Override
//	public CustomerPolicy saveCustomerPolicyById(CustomerPolicy user) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	public CustomerPolicy findByCustomerPolicyId(Integer customerpolicyid) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	public void delete(CustomerPolicy customer) {
//		// TODO Auto-generated method stub
//
//	}
//
//	public CustomerPolicy save(CustomerPolicy customer) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//}
