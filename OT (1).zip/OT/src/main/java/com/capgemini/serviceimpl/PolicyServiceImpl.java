package com.capgemini.serviceimpl;
import java.util.List;
import java.util.NoSuchElementException;

 

 

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

 

 

import com.capgemini.entity.CustomerPolicy;
import com.capgemini.entity.Policy;
import com.capgemini.exceptions.ResourceNotFoundException;
import com.capgemini.repository.CustomerRepo;
import com.capgemini.repository.PolicyRepo;
import com.capgemini.service.PolicyService;

 

 

@Service
public class PolicyServiceImpl implements PolicyService {

 

 

    public static final Logger logger = LoggerFactory.getLogger(PolicyServiceImpl.class);

 

 

    @Autowired
    CustomerRepo customerRepository;

 

 

    @Autowired
    private PolicyRepo policyRepository;

 

 

    public List<Policy> getAllPolicies() {
        logger.info("Policy Service get all");
        return (List<Policy>) policyRepository.findAll();
    }
@Override
    public Policy findPolicyById(@PathVariable(value = "id") Integer policyid) throws ResourceNotFoundException {

 

 

        logger.info("Policy Service get by id");
        try {
            Policy policy = policyRepository.findById(policyid).get();
            if(policy != null) {
                return policy;
            }
        } catch (NoSuchElementException e) {
            // TODO: handle exception
            throw new ResourceNotFoundException("Policy not found for this id :: " + policyid);
        }

 

        return null;

 

    }

 

 

    public List<CustomerPolicy> findByCustomerIdAndPolicyId(int customerId, int policyNo) {
        return (List<CustomerPolicy>) CustomerPolicy.findByCustomerIdAndPolicyId(customerId, policyNo);
    }

 

 

    public boolean deletePolicyById(Integer policyid) throws ResourceNotFoundException {
        logger.info(" Delete Policy Service by Id");
        Policy policy1 = policyRepository.findById(policyid)
                .orElseThrow(() -> new ResourceNotFoundException("Policy ot found for this id :: " + policyid));
        Object delete;
        policyRepository.delete(policy1);
        if (null == policy1) {
            return true;
        }
        return false;
    }

 

 

    public Policy savePolicy(Policy policy) throws ResourceNotFoundException {

      return  policyRepository.save(policy);

 

    }
    @Override
    public Policy updatePolicy( Policy policies) throws ResourceNotFoundException {
        try {
            Policy policy=policyRepository.findById(policies.getId()).get();
            if(policy != null)
            {
            return    policyRepository.save(policies);
            }
        } catch (NoSuchElementException e) {
            // TODO: handle exception
            throw new ResourceNotFoundException("PolicyNotFound");
        }
        return null;
    }
    @Override
    public Boolean deletePolicy(Integer policyid) {
        // TODO Auto-generated method stub
        return null;
    }

 

 

    

 

 



 

}