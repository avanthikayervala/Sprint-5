//package com.capgemini.serviceimpl;
//
//import java.util.List;
//
//import javax.xml.bind.ValidationException;
//
//
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//import org.springframework.transaction.annotation.Transactional;
//
//import com.capgemini.entity.Customer;
//import com.capgemini.entity.Login;
//import com.capgemini.exceptions.ResourceNotFoundException;
//import com.capgemini.repository.CustomerRepo;
//import com.capgemini.repository.LoginRepository;
//import com.capgemini.service.LoginService;
//
//@Service
//@Transactional
//
//public class LoginServiceImpl implements LoginService {
//	           public static final Logger logger = LoggerFactory.getLogger(PaymentServiceImpl.class);
//	           @Autowired
//	           LoginRepository loginRepository;
//	           
//	           @Autowired
//	           CustomerRepo customerRepository;
//	           
//	          
//	           public Login addCustomerCredentials(Login l) throws ValidationException, ResourceNotFoundException {
//	                      Customer customer = new Customer();
//	                      String k = l.getCustomerType();
//	                      String j = l.getCustomerName();
//	                      String u = l.getPassword();
//
//	                      String regularExpression = "^[A-Za-z][A-Za-z0-9]{3,20}$";
//	                      String regularExpressionpass = "^(?=.*[A-Za-z])(?=.*\\d)(?=.*[@$!%*#?&])[A-Za-z\\d@$!%*#?&]{8,}$";
//	                      if (!j.matches(regularExpression)) {
//	                                 throw new ValidationException("invalid customername try again.."
//	                                                       + "Rules --> first letter must be an alphabet and minmum 3 characters");
//	                      } else if (!u.matches(regularExpressionpass)) {
//	                                 throw new ValidationException("invalid password try again.."
//	                                                       + "Minimum eight characters, at least one letter, one number and one special character");
//	                      }
//
//	                      else if (k == "" || k == null) {
//	                                 throw new ValidationException("Customer type must not be empty");
//	                      }
//
//	                      try {
//	                                 String name = customerRepository.findByName(j).getName();
//	                                 customer = customerRepository.findByName(name);
//	                                 l.setCustomer(customer);
//	                                 loginRepository.save(l);
//	                      } catch (NullPointerException ex) {
//	                                 throw new ResourceNotFoundException("customername not found enter valid customername....");
//	                      }
//	                      return l;
//	           }
//	           
//	          
//	           @Override
//	           public String deleteCustomerCredentials(String customername, String password) throws ValidationException, ResourceNotFoundException {
//	                      try {
//	                                 String s = LoginRepository.findByCustomerName(customername).getCustomerName();
//	                                 Login l = LoginRepository.findByCustomerName(s);
//
//	                                 if (!password.equals(l.getPassword())) {
//	                                            throw new ValidationException("password mismatch try again...");
//	                                 } else {
//	                                            loginRepository.delete(l);
//	                                            customerRepository.delete(l.getCustomer());
//	                                 }
//
//	                      } catch (NullPointerException e) {
//	                                 throw new ResourceNotFoundException("customername not found enter valid customername....");
//	                      }
//	                      return "deleted customer:  " + customername;
//	           }         
//	
//	           @Override
//	           public String updateCustomerCredentials(String customername, String password,String email) throws ResourceNotFoundException {
//	                      try {
//	                                 String s = LoginRepository.findByCustomerName(customername).getCustomerName();
//	                                 Login l = LoginRepository.findByCustomerName(s);
//	                                 l.setPassword(password);
//	                                 l.setEmail(email);
//	                                 loginRepository.save(l);
//	                      } catch (NullPointerException ex) {
//	                                 throw new ResourceNotFoundException("customername not found enter valid customername....");
//	                      }
//	                      return "password changed sucessfully "+customername;
//	           }
//	           
//
//	           
//	           
//	          
//	           public Login getLoginByCustomerName1(String customername,String password)
//	           {
//	                      return loginRepository.getLoginByCustomerName(customername, password);
//	           }
//	           
//	           
//	    public List<Login> getAllCustomerCredentials()
//	           {
//	                      logger.info("Login Service get all");
//	                      return loginRepository.findAll();
//	                      
//	           }
//
//
//       public Login addCustomerCredentials1(Login l) {
//			// TODO Auto-generated method stub
//			return null;
//		}
//
//
//		public Login getLoginByCustomerName(String customername, String password) {
//			// TODO Auto-generated method stub
//			return null;
//		}
//
//
//		public String updateCustomerCredentials(String customerName, String password) {
//			// TODO Auto-generated method stub
//			return null;
//		}
//
//
//		@Override
//		public Login addCustomerCredentials11(Login l) throws ValidationException, ResourceNotFoundException {
//			// TODO Auto-generated method stub
//			return null;
//		}
//
//
//		@Override
//		public String deleteUserCredentials(String username, String password)
//				throws ValidationException, ResourceNotFoundException {
//			// TODO Auto-generated method stub
//			return null;
//		}
//
//
//		@Override
//		public String updateUserCredentials(String username, String password, String email)
//				throws ResourceNotFoundException {
//			// TODO Auto-generated method stub
//			return null;
//		}
//
//
//		@Override
//		public List<Login> getAllCustomerCredentials1() {
//			// TODO Auto-generated method stub
//			return null;
//		}
//
//
//		@Override
//		public Login addUserCredentials(Login l) throws ValidationException, ResourceNotFoundException {
//			// TODO Auto-generated method stub
//			return null;
//		}
//
//
//		@Override
//		public List<Login> getAllUserCredentials() {
//			// TODO Auto-generated method stub
//			return null;
//		}
//
//
//		
//
//		
//	           
//
//
//}
