package com.capgemini.serviceimpl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.entity.Payments;
import com.capgemini.entity.Policy;
import com.capgemini.repository.PaymentRepository;
import com.capgemini.service.PaymentService;



@Service
public class PaymentServiceImpl implements PaymentService{
    
    
    public static final Logger logger = LoggerFactory.getLogger(PaymentServiceImpl.class);
    @Autowired
    PaymentRepository paymentRepository;
    
    @Override
    public List<Payments> getAll()
    {
               logger.info("Payment Service get all");
               return paymentRepository.findAll();
               
    }
    @Override
    public List<Payments> findByCustomerIdAndPolicyNo(int customerId,int policyNo)
    {
               logger.info("Payment Service find by CustomerIdAndPolicyNo");
               return paymentRepository.findByCustomerIdAndPolicyNo(customerId,policyNo);
    }
    @Override
    public double findTotalAmountPaid(int customerId,int policyNo)
    {
               logger.info("Payment Service total amount paid");
               return paymentRepository.findTotalAmountPaid(customerId,policyNo);
    }
    @Override
    public Payments MakePayment(Payments pp)
    {
               logger.info("Payment Service make Payment");
               return paymentRepository.save(pp);
               
    }
   
    @Override
    public Payments findByReceiptNo(int receiptNo)
    {
               logger.info("Payment Service findbyreciept no");
               return paymentRepository.findByReceiptNo(receiptNo);
    }
	
	@Override
	public List<Payments> findAllCustomerId(int customerId) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public double findTotalAmountPaid(int customerId) {
		// TODO Auto-generated method stub
		return 0;
	}
	public List<Payments> getall() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public List<Payments> getAll1() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public List<Payments> findByCustomerIdAndPolicyNo1(int customerId, int policyNo) {
		// TODO Auto-generated method stub
		return null;
	}
	public Policy savePolicy(Policy policy1) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public boolean deletePayment(Payments payment) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public List<Payments> findByUserIdAndPolicyNo(int userId, int policyNo) {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	


}
